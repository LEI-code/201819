cat $1 $2 > $3
wc -l < $3