#!/bin/bash
echo "How do you list a **the login** of the users!?!?"